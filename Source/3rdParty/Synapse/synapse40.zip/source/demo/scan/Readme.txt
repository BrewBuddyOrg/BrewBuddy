Scan v1.0
Synapse Demo Application
(c) 2003 by Christian Brosius (brosius@online.de)

'Scan v1.0' is a multithreaded ping to scan a given networkrange for 
available IP-Adresses.

Usage:

'scan 192.168.50.1 192.168.50.254' scans a complete Class C Network with
a timeout for each ping of 2 Seconds.

The complete Scan will finish after about 3 Seconds.

The result will be a sorted list of available IP-Adresses.

